[{"url": "https://raw.githubusercontent.com/kodishmediacenter/omega/master/tw-cas", "fanart": ".\\fanart.jpg", "title": "CANAIS"}]
